<?php
function enc($s) { return str_replace(['+','/','='], ['-','_',''], base64_encode((string)$s)); }
function dec($s) {
    $s = (string)$s;
    $p = 4 - strlen($s) % 4;
    $s .= str_repeat('=', $p === 4 ? 0 : $p);
    $d = @base64_decode(str_replace(['-','_'], ['+','/'], $s), true);
    return $d !== false ? $d : '';
}

$a = "<?php echo 'hello'; ?>";
$b = enc($a);
$c = dec($b);
echo "Original: $a\nEncoded: $b\nDecoded: $c\n";
if ($a === $c) echo "SUCCESS\n";
