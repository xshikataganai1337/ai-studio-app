<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

function enc($s) { return str_replace(['+','/','='], ['-','_',''], base64_encode((string)$s)); }
function dec($s) {
    $s = (string)$s;
    $p = 4 - strlen($s) % 4;
    $s .= str_repeat('=', $p === 4 ? 0 : $p);
    $d = @base64_decode(str_replace(['-','_'], ['+','/'], $s), true);
    return $d !== false ? $d : '';
}

$base_dir = realpath(__DIR__);
if ($base_dir === false) $base_dir = __DIR__;
echo enc('config.php') . "\n";
