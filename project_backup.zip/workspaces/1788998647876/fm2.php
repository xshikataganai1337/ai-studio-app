<?php
$encoded = base64_encode('config.php');
echo $encoded;
