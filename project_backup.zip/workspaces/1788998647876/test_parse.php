<?php
// Mematikan tampilan error mentah yang dapat merusak struktur HTML, 
// meskipun secara internal kode ini sudah dijamin bebas dari notice/warning.
error_reporting(E_ALL);
ini_set('display_errors', '0');

session_start();

// 1. Path Resolutions & Sanitization (Safe for PHP 7.4 -> 8.5+)
$base_dir = (string)(realpath(__DIR__) ?: __DIR__);
$dir_param = isset($_GET['dir']) ? (string)$_GET['dir'] : '';
$current_dir = realpath($base_dir . '/' . $dir_param);

// Mencegah directory traversal di atas level root manager
if ($current_dir === false || strpos((string)$current_dir, $base_dir) !== 0) {
    $current_dir = $base_dir;
}
