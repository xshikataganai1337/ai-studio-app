<?php
// Mematikan tampilan error mentah yang dapat merusak struktur HTML, 
// meskipun secara internal kode ini sudah dijamin bebas dari notice/warning.
error_reporting(E_ALL);
ini_set('display_errors', '0');

session_start();

$base_dir = realpath(__DIR__);
if ($base_dir === false) {
    $base_dir = __DIR__;
}

$dir_param = '';
if (isset($_GET['dir'])) {
    $dir_param = (string)$_GET['dir'];
}

$current_dir = realpath($base_dir . '/' . $dir_param);

// Mencegah directory traversal
$is_valid_dir = true;
if ($current_dir === false) {
    $is_valid_dir = false;
} else {
    $current_dir_str = (string)$current_dir;
    if (strpos($current_dir_str, $base_dir) !== 0) {
        $is_valid_dir = false;
    }
}

if ($is_valid_dir === false) {
    $current_dir = $base_dir;
}

$relative_dir = '/';
$len_current = strlen((string)$current_dir);
$len_base = strlen($base_dir);

if ($len_current > $len_base) {
    $relative_dir = substr((string)$current_dir, $len_base);
}

$relative_dir = str_replace('\\', '/', (string)$relative_dir);
$relative_dir = ltrim($relative_dir, '/');

$action = '';
if (isset($_GET['a'])) {
    $action = (string)$_GET['a'];
}

$file = '';
if (isset($_GET['f'])) {
    $file = (string)$_GET['f'];
}

$target_file = false;
if ($file !== '') {
    $target_file = realpath($current_dir . '/' . $file);
}

if ($target_file !== false) {
    $target_file_str = (string)$target_file;
    if (strpos($target_file_str, $base_dir) !== 0) {
        $target_file = false;
    }
}

// POST Actions Handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post_action = '';
    if (isset($_POST['action'])) {
        $post_action = (string)$_POST['action'];
    }
    
    $post_filename = '';
    if (isset($_POST['filename'])) {
        $post_filename = (string)$_POST['filename'];
    }
    
    $tgt = '';
    if ($post_filename !== '') {
        $tgt = $current_dir . '/' . $post_filename;
    }
    
    if ($post_action === 'edit') {
        if (isset($_POST['content'])) {
            if ($tgt !== '') {
                if (file_exists($tgt) && is_file($tgt) && is_writable($tgt)) {
                    @file_put_contents($tgt, (string)$_POST['content']);
                }
            }
        }
        header("Location: ?dir=" . urlencode($relative_dir));
        exit;
    }
    
    if ($post_action === 'rename') {
        if (isset($_POST['new_name']) && isset($_POST['old_name'])) {
            $old = $current_dir . '/' . (string)$_POST['old_name'];
            $new = $current_dir . '/' . (string)$_POST['new_name'];
            if (file_exists($old) && !file_exists($new) && is_writable($current_dir)) {
                @rename($old, $new);
            }
        }
        header("Location: ?dir=" . urlencode($relative_dir));
        exit;
    }
    
    if ($post_action === 'delete') {
        if ($tgt !== '') {
            if (file_exists($tgt)) {
                if (is_dir($tgt)) {
                    @rmdir_recursive($tgt);
                } else {
                    @unlink($tgt);
                }
            }
        }
        header("Location: ?dir=" . urlencode($relative_dir));
        exit;
    }
    
    if ($post_action === 'chmod') {
        if (isset($_POST['mode'])) {
            if ($tgt !== '') {
                $mode_str = (string)$_POST['mode'];
                if (file_exists($tgt)) {
                    @chmod($tgt, octdec($mode_str));
                }
            }
        }
        header("Location: ?dir=" . urlencode($relative_dir));
        exit;
    }
}

// Helper Functions
function rmdir_recursive($dir) {
    if (!is_dir($dir)) return;
    $items = @scandir($dir);
    if (is_array($items)) {
        foreach($items as $f) {
            if ($f === '.') continue;
            if ($f === '..') continue;
            $path = $dir . '/' . $f;
            if (is_dir($path)) rmdir_recursive($path);
            else @unlink($path);
        }
    }
    @rmdir($dir);
}

function get_perms($file) {
    $perms = @fileperms($file);
    if ($perms === false) return 'unknown';

    if (($perms & 0xC000) == 0xC000) $info = 's';
    elseif (($perms & 0xA000) == 0xA000) $info = 'l';
    elseif (($perms & 0x8000) == 0x8000) $info = '-';
    elseif (($perms & 0x6000) == 0x6000) $info = 'b';
    elseif (($perms & 0x4000) == 0x4000) $info = 'd';
    elseif (($perms & 0x2000) == 0x2000) $info = 'c';
    elseif (($perms & 0x1000) == 0x1000) $info = 'p';
    else $info = 'u';

    $info .= (($perms & 0x0100) ? 'r' : '-');
    $info .= (($perms & 0x0080) ? 'w' : '-');
    $info .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x' ) : (($perms & 0x0800) ? 'S' : '-'));
    $info .= (($perms & 0x0020) ? 'r' : '-');
    $info .= (($perms & 0x0010) ? 'w' : '-');
    $info .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x' ) : (($perms & 0x0400) ? 'S' : '-'));
    $info .= (($perms & 0x0004) ? 'r' : '-');
    $info .= (($perms & 0x0002) ? 'w' : '-');
    $info .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x' ) : (($perms & 0x0200) ? 'T' : '-'));
    
    return $info;
}

function format_size($bytes) {
    if (!is_numeric($bytes)) return '-';
    if ($bytes < 0) return '-';
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

$dirs = [];
$files = [];
$items = @scandir($current_dir);
if (is_array($items)) {
    foreach ($items as $item) {
        if ($item === '.') continue;
        if ($item === '..') {
            if ($current_dir === $base_dir) continue;
        }
        
        $path = $current_dir . '/' . $item;
        if (@is_dir($path)) $dirs[] = $item;
        else $files[] = $item;
    }
}
natcasesort($dirs);
natcasesort($files);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FM Workspace</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg-base: #09090b; /* Deep slate */
    --bg-surface: #121214;
    --bg-surface-hover: #1f1f23;
    --border: #27272a;
    --border-focus: #52525b;
    --text-primary: #f4f4f5;
    --text-secondary: #a1a1aa;
    --accent: #d4d4d8; /* Refined neutral accent */
    --danger: #ef4444;
    --font-ui: "Inter", -apple-system, sans-serif;
    --font-mono: "JetBrains Mono", monospace;
  }
  
  * { box-sizing: border-box; margin: 0; padding: 0; }
  
  body {
    background-color: var(--bg-base);
    color: var(--text-primary);
    font-family: var(--font-ui);
    font-size: 14px;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
    padding: 2rem 1.5rem;
  }

  .container { 
    max-width: 900px; 
    margin: 0 auto; 
  }
  
  /* Minimalist Header */
  header {
    display: flex;
    align-items: center;
    padding: 1rem 0 1.5rem 0;
    margin-bottom: 1.5rem;
  }
  
  .path { 
    font-family: var(--font-mono); 
    font-size: 0.9rem; 
    font-weight: 500; 
    display: flex; 
    align-items: center; 
    gap: 0.5rem; 
    flex-wrap: wrap; 
    background: var(--bg-surface);
    padding: 0.75rem 1.25rem;
    border: 1px solid var(--border);
    border-radius: 6px;
    width: 100%;
  }
  .path a { color: var(--text-secondary); text-decoration: none; transition: color 0.2s; }
  .path a:hover { color: var(--text-primary); }
  .path .sep { color: var(--border); }
  
  /* Glass/Soft-Surface Panel for Actions */
  .panel {
    background: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 2rem;
  }
  .panel h2 { 
    margin-bottom: 1.25rem; 
    font-size: 0.9rem; 
    font-weight: 600; 
    color: var(--text-primary); 
  }
  
  .form-group { margin-bottom: 1rem; }
  input[type="text"], textarea {
    width: 100%;
    background: var(--bg-base);
    border: 1px solid var(--border);
    color: var(--text-primary);
    padding: 0.75rem 1rem;
    font-family: var(--font-mono);
    font-size: 0.9rem;
    border-radius: 4px;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  textarea { height: 400px; resize: vertical; line-height: 1.5; }
  input:focus, textarea:focus { 
    outline: none; 
    border-color: var(--border-focus); 
  }
  
  /* Refined Brutalist Buttons */
  .btn {
    background: transparent;
    border: 1px solid var(--border);
    color: var(--text-secondary);
    padding: 0.4rem 0.8rem;
    font-size: 0.75rem;
    font-family: var(--font-mono);
    text-decoration: none;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.2s;
  }
  .btn:hover { 
    background: var(--bg-surface-hover); 
    color: var(--text-primary); 
    border-color: var(--border-focus); 
  }
  .btn.danger:hover { 
    background: rgba(239, 68, 68, 0.1); 
    color: var(--danger); 
    border-color: var(--danger); 
  }
  
  .btn-submit {
    background: var(--text-primary);
    color: var(--bg-base);
    border: 1px solid var(--text-primary);
    padding: 0.75rem 1.5rem;
    font-weight: 500;
    font-size: 0.85rem;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.2s;
  }
  .btn-submit:hover { 
    background: var(--accent); 
    color: var(--bg-base);
  }
  
  /* Modern Table Data Grid */
  .grid-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    border: 1px solid var(--border);
    border-radius: 8px;
    overflow: hidden;
  }
  th, td { 
    text-align: left; 
    padding: 0.85rem 1.25rem; 
    border-bottom: 1px solid var(--border); 
  }
  th { 
    background: var(--bg-surface);
    color: var(--text-secondary); 
    font-weight: 500; 
    font-size: 0.75rem; 
    text-transform: uppercase; 
    letter-spacing: 0.05em; 
  }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: var(--bg-surface-hover); }
  
  td.name { 
    font-family: var(--font-mono); 
    display: flex; 
    align-items: center; 
    gap: 0.85rem; 
    font-size: 0.9rem;
  }
  td.name a { 
    color: var(--text-primary); 
    text-decoration: none; 
    word-break: break-all; 
    transition: color 0.2s; 
  }
  td.name a:hover { color: #fff; text-decoration: underline; }
  
  td.size, td.perms { 
    font-family: var(--font-mono); 
    color: var(--text-secondary); 
    font-size: 0.85rem; 
  }
  
  .actions { display: flex; gap: 0.4rem; }
  
  /* Icons */
  .icon { width: 1.1rem; height: 1.1rem; flex-shrink: 0; }
  .icon-dir { stroke: var(--text-secondary); fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
  .icon-file { stroke: var(--border-focus); fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }

  /* Responsive Design */
  @media (max-width: 768px) {
    th.size, td.size, th.perms, td.perms { display: none; }
    .actions { flex-wrap: wrap; }
    td.name { flex-direction: column; align-items: flex-start; gap: 0.5rem; }
    body { padding: 1rem 0.75rem; }
    .btn { padding: 0.3rem 0.6rem; font-size: 0.7rem; }
    .grid-table { border-radius: 6px; }
  }
</style>
</head>
<body>
<div class="container">
  <header>
    <div class="path">
      <svg class="icon icon-dir" viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
      <?php
      $parts = explode('/', trim((string)$relative_dir, '/'));
      echo '<a href="?dir=">~</a>';
      $accum = '';
      foreach($parts as $p) {
        if ($p === '') continue;
        $accum .= '/' . $p;
        echo '<span class="sep">/</span>';
        echo '<a href="?dir='.urlencode(ltrim($accum, '/')).'">'.htmlspecialchars((string)$p).'</a>';
      }
      ?>
    </div>
  </header>

  <?php if ($action !== '' && $target_file !== false && file_exists($target_file)): ?>
    <?php if ($action === 'edit' && is_file($target_file)): ?>
      <div class="panel">
        <h2>Editing: <?php echo htmlspecialchars((string)$file); ?></h2>
        <form method="POST" action="?dir=<?php echo urlencode((string)$relative_dir); ?>">
          <input type="hidden" name="action" value="edit">
          <input type="hidden" name="filename" value="<?php echo htmlspecialchars((string)$file); ?>">
          <div class="form-group">
            <textarea name="content" spellcheck="false"><?php echo htmlspecialchars((string)@file_get_contents($target_file)); ?></textarea>
          </div>
          <button type="submit" class="btn-submit">Save File</button>
          <a href="?dir=<?php echo urlencode((string)$relative_dir); ?>" class="btn" style="margin-left: 10px; padding: 0.75rem 1.5rem; border:none; background: transparent;">Cancel</a>
        </form>
      </div>
    <?php elseif ($action === 'rename'): ?>
      <div class="panel">
        <h2>Rename: <?php echo htmlspecialchars((string)$file); ?></h2>
        <form method="POST" action="?dir=<?php echo urlencode((string)$relative_dir); ?>">
          <input type="hidden" name="action" value="rename">
          <input type="hidden" name="old_name" value="<?php echo htmlspecialchars((string)$file); ?>">
          <div class="form-group">
            <input type="text" name="new_name" value="<?php echo htmlspecialchars((string)$file); ?>" autofocus>
          </div>
          <button type="submit" class="btn-submit">Rename</button>
          <a href="?dir=<?php echo urlencode((string)$relative_dir); ?>" class="btn" style="margin-left: 10px; padding: 0.75rem 1.5rem; border:none; background: transparent;">Cancel</a>
        </form>
      </div>
    <?php elseif ($action === 'chmod'): ?>
      <div class="panel">
        <h2>Chmod: <?php echo htmlspecialchars((string)$file); ?></h2>
        <form method="POST" action="?dir=<?php echo urlencode((string)$relative_dir); ?>">
          <input type="hidden" name="action" value="chmod">
          <input type="hidden" name="filename" value="<?php echo htmlspecialchars((string)$file); ?>">
          <div class="form-group">
            <?php 
                $fp = @fileperms($target_file);
                $mode_val = $fp !== false ? substr(sprintf('%o', $fp), -4) : '0644';
            ?>
            <input type="text" name="mode" value="<?php echo htmlspecialchars((string)$mode_val); ?>" autofocus>
          </div>
          <button type="submit" class="btn-submit">Update Permission</button>
          <a href="?dir=<?php echo urlencode((string)$relative_dir); ?>" class="btn" style="margin-left: 10px; padding: 0.75rem 1.5rem; border:none; background: transparent;">Cancel</a>
        </form>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <table class="grid-table">
    <thead>
      <tr>
        <th>Name</th>
        <th class="size">Size</th>
        <th class="perms">Perms</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($dirs as $d): 
        $dpath = $current_dir . '/' . $d;
      ?>
      <tr>
        <td class="name">
          <svg class="icon icon-dir" viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir . '/' . $d, '/')); ?>"><?php echo htmlspecialchars((string)$d); ?></a>
        </td>
        <td class="size">-</td>
        <td class="perms"><?php echo get_perms($dpath); ?></td>
        <td class="actions">
          <?php if($d !== '..'): ?>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir, '/')); ?>&a=rename&f=<?php echo urlencode((string)$d); ?>" class="btn">ren</a>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir, '/')); ?>&a=chmod&f=<?php echo urlencode((string)$d); ?>" class="btn">mod</a>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Delete directory and all its contents?');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="filename" value="<?php echo htmlspecialchars((string)$d); ?>">
            <button type="submit" class="btn danger">del</button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      
      <?php foreach ($files as $f): 
        $fpath = $current_dir . '/' . $f;
        $fsize = @filesize($fpath);
      ?>
      <tr>
        <td class="name">
          <svg class="icon icon-file" viewBox="0 0 24 24"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
          <?php echo htmlspecialchars((string)$f); ?>
        </td>
        <td class="size"><?php echo format_size($fsize !== false ? $fsize : -1); ?></td>
        <td class="perms"><?php echo get_perms($fpath); ?></td>
        <td class="actions">
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir, '/')); ?>&a=edit&f=<?php echo urlencode((string)$f); ?>" class="btn">edit</a>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir, '/')); ?>&a=rename&f=<?php echo urlencode((string)$f); ?>" class="btn">ren</a>
          <a href="?dir=<?php echo urlencode(ltrim($relative_dir, '/')); ?>&a=chmod&f=<?php echo urlencode((string)$f); ?>" class="btn">mod</a>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Delete file permanently?');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="filename" value="<?php echo htmlspecialchars((string)$f); ?>">
            <button type="submit" class="btn danger">del</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
</body>
</html>
