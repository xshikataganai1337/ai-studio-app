<?php
$a = false | | true;
